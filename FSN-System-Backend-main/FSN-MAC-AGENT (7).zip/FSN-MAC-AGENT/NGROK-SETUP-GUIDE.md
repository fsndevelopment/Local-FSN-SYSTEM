# NGROK Setup Guide for FSN System

## Overview
This guide shows how to make your local Mac backend accessible to remote clients using ngrok, while keeping the iPhone connection working.

## How It Works
```
fsndevelopment.com frontend → ngrok URL → YOUR Mac backend → YOUR iPhone
```

## Step 1: Install ngrok on Mac
```bash
# Option A: Using Homebrew
brew install ngrok

# Option B: Download from website
# Go to https://ngrok.com/download and download for Mac
```

## Step 2: Start Your Backend
```bash
cd /path/to/FSN-MAC-AGENT
python3 local-backend.py
```
Backend will run on `http://localhost:8000`

## Step 3: Start ngrok Tunnel
In a new terminal:
```bash
ngrok http 8000
```

You'll get output like:
```
Forwarding    https://abc123.ngrok.io -> http://localhost:8000
```

**Copy the https URL** (e.g., `https://abc123.ngrok.io`)

## Step 4: Test Connection
From any computer, test:
```bash
curl https://abc123.ngrok.io/api/v1/devices
```

Should return your device list.

## Step 5: Update Frontend
Update the frontend to use your ngrok URL instead of localhost.

## For Clients
Each client needs to:
1. Run their own backend on their Mac
2. Start their own ngrok tunnel
3. Update frontend to use their ngrok URL
4. Connect their iPhone to their Mac

## Benefits
- ✅ Live frontend at fsndevelopment.com works
- ✅ License system works normally
- ✅ Real iPhone connection maintained
- ✅ Remote client access possible

## Troubleshooting
- Make sure backend binds to `0.0.0.0:8000` (already configured)
- Check ngrok is running and URL is active
- Verify iPhone is connected to the correct Mac

