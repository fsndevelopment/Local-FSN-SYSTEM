# Client Deployment Guide

## For Each Client

### What Each Client Needs
1. **Mac computer** with iPhone connected
2. **FSN backend code** (this folder)
3. **ngrok account** (free)
4. **License key** from you

### Client Setup Steps

#### Step 1: Download Backend Code
```bash
git clone https://github.com/fsndevelopment/FSN-System-Backend.git
cd FSN-System-Backend/FSN-MAC-AGENT
```

#### Step 2: Install Dependencies
```bash
pip3 install -r requirements.txt
```

#### Step 3: Configure Their iPhone
Edit `local-backend.py` and update the device with their iPhone details:
```python
devices = [
    {
        "id": "4",
        "udid": "THEIR_IPHONE_UDID",  # Replace with their iPhone UDID
        "name": "iPhone11",
        "ios_version": "17.0",
        "model": "iPhone 11",
        "appium_port": 4741,  # Their Appium port
        "wda_port": 8109,     # Their WDA port
        "wda_bundle_id": "com.device11.wd11",  # Their WDA bundle
        # ... other settings
    }
]
```

#### Step 4: Start Backend
```bash
python3 local-backend.py
```

#### Step 5: Start ngrok
In another terminal:
```bash
ngrok http 8000
```

Copy the https URL (e.g., `https://xyz789.ngrok.io`)

#### Step 6: Update Frontend
They need to update the frontend to use their ngrok URL.

### Your Role as Provider
1. **Give them the backend code**
2. **Provide their license key**
3. **Help them configure their iPhone details**
4. **Update frontend to use their ngrok URL**

### Client Benefits
- ✅ Use live frontend at fsndevelopment.com
- ✅ License system works
- ✅ Control their own iPhone
- ✅ Remote access from anywhere

### Your Benefits
- ✅ No server costs
- ✅ Each client manages their own setup
- ✅ License control maintained
- ✅ Real phone automation working

