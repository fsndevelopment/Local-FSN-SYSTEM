#!/usr/bin/env python3
"""
FSN Local Backend for Mac
Connects to your frontend and starts Appium processes locally
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn
import subprocess
import time
import json
import os
import psutil
from datetime import datetime

app = FastAPI(title="FSN Local Backend", version="1.0.0")

# Allow CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for devices and jobs
devices = []
jobs = []
running_appium_processes = {}  # device_id -> process

class Device(BaseModel):
    id: str
    udid: str
    platform: str
    name: str
    status: str
    appium_port: int
    wda_port: int
    mjpeg_port: int
    last_seen: str

class Job(BaseModel):
    id: str
    device_id: str
    account_id: str
    type: str
    status: str
    created_at: str

class StartDeviceRequest(BaseModel):
    device_id: str
    job_type: str = "automation"

@app.get("/")
async def root():
    return {"message": "FSN Local Backend is running!", "version": "1.0.0"}

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Device endpoints - compatible with your frontend
@app.get("/api/v1/devices")
async def get_devices():
    return {"devices": devices, "total": len(devices)}

@app.post("/api/v1/devices")
async def create_device(device: Device):
    device.id = f"device-{int(time.time())}"
    device.last_seen = datetime.now().isoformat()
    devices.append(device)
    print(f"📱 Device registered: {device.name} ({device.udid})")
    return device

@app.post("/api/v1/devices/{device_id}/heartbeat")
async def device_heartbeat(device_id: str):
    for device in devices:
        if device.id == device_id:
            device.last_seen = datetime.now().isoformat()
            return {"status": "success"}
    raise HTTPException(status_code=404, detail="Device not found")

# THE MAIN ENDPOINT - Start device from frontend
@app.post("/api/v1/devices/{device_id}/start")
async def start_device(device_id: str, request: StartDeviceRequest):
    """Start Appium for a specific device when called from frontend"""
    
    # Find the device
    device = None
    for d in devices:
        if d.id == device_id:
            device = d
            break
    
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    print(f"🚀 Starting device: {device.name}")
    print(f"   Platform: {device.platform}")
    print(f"   UDID: {device.udid}")
    print(f"   Appium Port: {device.appium_port}")
    
    # Check if Appium is already running for this device
    if device_id in running_appium_processes:
        process = running_appium_processes[device_id]
        if process.poll() is None:  # Process is still running
            print(f"✅ Appium already running for {device.name}")
            return {"status": "already_running", "device_id": device_id}
    
    try:
        # Start Appium server for this device
        appium_cmd = [
            "appium",
            "--port", str(device.appium_port),
            "--bootstrap-port", str(device.wda_port),
            "--session-override",
            "--log-level", "info"
        ]
        
        print(f"🔧 Starting Appium command: {' '.join(appium_cmd)}")
        
        # Start Appium process
        process = subprocess.Popen(
            appium_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # Store the process
        running_appium_processes[device_id] = process
        
        # Update device status
        device.status = "running"
        
        print(f"✅ Appium started successfully!")
        print(f"   PID: {process.pid}")
        print(f"   Access at: http://localhost:{device.appium_port}")
        print(f"   Device ready for automation!")
        
        return {
            "status": "started",
            "device_id": device_id,
            "appium_port": device.appium_port,
            "pid": process.pid
        }
        
    except Exception as e:
        print(f"❌ Failed to start Appium: {e}")
        device.status = "error"
        raise HTTPException(status_code=500, detail=f"Failed to start Appium: {str(e)}")

@app.post("/api/v1/devices/{device_id}/stop")
async def stop_device(device_id: str):
    """Stop Appium for a specific device"""
    
    if device_id in running_appium_processes:
        process = running_appium_processes[device_id]
        if process.poll() is None:  # Process is still running
            process.terminate()
            process.wait()
            print(f"🛑 Appium stopped for device {device_id}")
        
        del running_appium_processes[device_id]
        
        # Update device status
        for device in devices:
            if device.id == device_id:
                device.status = "stopped"
                break
        
        return {"status": "stopped", "device_id": device_id}
    else:
        return {"status": "not_running", "device_id": device_id}

# Job endpoints
@app.get("/api/v1/jobs")
async def get_jobs():
    return {"jobs": jobs, "total": len(jobs)}

@app.post("/api/v1/jobs")
async def create_job(job: Job):
    job.id = f"job-{int(time.time())}"
    job.created_at = datetime.now().isoformat()
    jobs.append(job)
    return job

# Account endpoints
@app.get("/api/v1/accounts")
async def get_accounts():
    return {"accounts": [], "total": 0}

@app.post("/api/v1/accounts")
async def create_account(account: dict):
    return {"id": f"account-{int(time.time())}", **account}

# Templates endpoints (for frontend compatibility)
@app.get("/api/v1/templates")
async def get_templates():
    return {"templates": [], "total": 0}

@app.get("/api/v1/models")
async def get_models():
    return {"models": [], "total": 0}

# WebSocket endpoint (for real-time updates)
@app.get("/api/ws")
async def websocket_endpoint():
    return {"message": "WebSocket endpoint - implement if needed"}

if __name__ == "__main__":
    print("🚀 Starting FSN Local Backend...")
    print("📱 This runs on your Mac and connects to fsndevelopment.com")
    print("")
    print("📊 Available endpoints:")
    print("   - http://localhost:8000/api/v1/devices")
    print("   - http://localhost:8000/api/v1/devices/{id}/start")
    print("   - http://localhost:8000/api/v1/devices/{id}/stop")
    print("")
    print("🎯 How it works:")
    print("   1. Add devices in the frontend")
    print("   2. Click 'Start Device' in frontend")
    print("   3. This backend starts Appium for that device")
    print("   4. Your iPhone gets controlled by the frontend")
    print("")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)